import { createApp } from 'vue';
import App from './App';
// import App from './VueTemplate.vue';

createApp(App).mount('#app');
